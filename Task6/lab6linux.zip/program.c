#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h> // For usleep
#include <stdbool.h>
#include <errno.h> // Include errno.h for errno variable
#include <ctype.h> // Include ctype.h for islower

pthread_mutex_t mutex;
int sharedCounter = 0;

typedef struct {
    char* data;
    int start;
    int end;
} ThreadData;

void errorExit(const char* message) {
    fprintf(stderr, "%s error: %s\n", message, strerror(errno));
    exit(EXIT_FAILURE);
}

void* countLowerCase(void* param) {
    ThreadData* tData = (ThreadData*) param;
    int localCounter = 0;

    for (int i = tData->start; i < tData->end; i++) {
        if (islower(tData->data[i])) {
            localCounter++;
        }
    }

    if (pthread_mutex_lock(&mutex) != 0) {
        errorExit("Mutex lock");
    }

    sharedCounter += localCounter;

    if (pthread_mutex_unlock(&mutex) != 0) {
        errorExit("Mutex unlock");
    }

    printf("Thread %ld processed: %.*s\n", pthread_self(), tData->end - tData->start, tData->data + tData->start);
    printf("Thread %ld counted lowercase letters: %d\n", pthread_self(), localCounter);

    pthread_exit(NULL);
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <input_file> <number_of_threads>\n", argv[0]);
        exit(1);
    }

    if (pthread_mutex_init(&mutex, NULL) != 0) {
        errorExit("Mutex initialization");
    }

    char* filename = argv[1];
    int numThreads = atoi(argv[2]);

    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        errorExit("File opening");
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    rewind(file);

    if (fileSize < 2) {
        errorExit("File should contain at least 2 characters");
    }

    int maxThreads = fileSize / 2;
    if (numThreads > maxThreads) {
        numThreads = maxThreads;
        printf("Number of threads reduced to %d to meet the requirement.\n", numThreads);
    }

    char* fileContent = (char*)malloc(fileSize + 1);
    if (fileContent == NULL) {
        errorExit("Memory allocation");
    }

    if (fread(fileContent, 1, fileSize, file) != fileSize) {
        free(fileContent);
        fclose(file);
        errorExit("File reading");
    }
    fileContent[fileSize] = '\0';

    ThreadData* threadsData = (ThreadData*)malloc(numThreads * sizeof(ThreadData));
    if (threadsData == NULL) {
        free(fileContent);
        fclose(file);
        errorExit("Memory allocation for threads data");
    }

    pthread_t* threadHandles = (pthread_t*)malloc(numThreads * sizeof(pthread_t));
    if (threadHandles == NULL) {
        free(fileContent);
        free(threadsData);
        fclose(file);
        errorExit("Memory allocation for thread handles");
    }

    int segmentSize = fileSize / numThreads;
    int remainingChars = fileSize % numThreads;

    int currentStart = 0;
    for (int i = 0; i < numThreads; i++) {
        threadsData[i].data = fileContent;
        threadsData[i].start = currentStart;
        threadsData[i].end = currentStart + segmentSize + (i < remainingChars ? 1 : 0);

        currentStart = threadsData[i].end;
    }

    for (int i = 0; i < numThreads; i++) {
        if (pthread_create(&threadHandles[i], NULL, countLowerCase, &threadsData[i]) != 0) {
            free(fileContent);
            free(threadsData);
            fclose(file);
            errorExit("Thread creation");
        }
    }

    for (int i = 0; i < numThreads; i++) {
        if (pthread_join(threadHandles[i], NULL) != 0) {
            free(fileContent);
            free(threadsData);
            fclose(file);
            errorExit("Thread join");
        }
    }

    free(fileContent);
    free(threadsData);
    free(threadHandles);

    if (pthread_mutex_destroy(&mutex) != 0) {
        errorExit("Mutex destruction");
    }

    fclose(file);

    printf("Total lowercase letters in the file: %d\n", sharedCounter);

    exit(0);
}

