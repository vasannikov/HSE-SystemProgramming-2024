gcc program.c -o program.exe

program.exe C:\Users\vladi\OneDrive\Документы\lab6sysprog\input.txt.txt 4

cmd