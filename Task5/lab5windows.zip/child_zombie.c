#include <stdio.h>
#include <windows.h>

int main()
{
    // Просто здесь ничего не делаем для демонстрации "псевдо-зомби" состояния

    return 0;
}
