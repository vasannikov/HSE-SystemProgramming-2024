#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_FILE_SIZE 10000

void printErrorMessageAndExit(const char *errorMessage)
{
    fprintf(stderr, "%s\n", errorMessage);
    exit(1);
}

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        fprintf(stderr, "Usage: %s <input_file> <N>\n", argv[0]);
        exit(1);
    }

    const char *inputFileName = argv[1];
    int N = atoi(argv[2]);

    FILE *inputFile = fopen(inputFileName, "r");
    if (inputFile == NULL)
    {
        printErrorMessageAndExit("Error opening input file.");
    }

    fseek(inputFile, 0, SEEK_END);
    long fileSize = ftell(inputFile);
    fseek(inputFile, 0, SEEK_SET);

    if (fileSize < 2)
    {
        printErrorMessageAndExit("Input file must contain at least 2 characters.");
    }

    char inputString[MAX_FILE_SIZE];
    fread(inputString, sizeof(char), fileSize, inputFile);
    fclose(inputFile);

    int numberOfProcesses = N;
    int M = fileSize;

    if (N > M / 2)
    {
        numberOfProcesses = M / 2;
        printf("Reducing the number of child processes to %d\n", numberOfProcesses);
    }

    char command[100];
    int segmentSize = M / numberOfProcesses;
    int extraCharsLastProcess = M - (numberOfProcesses - 1) * (M / numberOfProcesses);
    int totalLowercaseCount = 0;
    int startPos = 0;
    int currentProcess = 0;

    while (startPos < M)
    {
        int segmentLength = (currentProcess == numberOfProcesses - 1) ? extraCharsLastProcess : segmentSize;

        printf("Creating child process %d for segment: ", currentProcess);
        for (int j = startPos; j < startPos + segmentLength; j++)
        {
            putchar(inputString[j]);
        }
        putchar('\n');

        pid_t pid = fork();

        if (pid == -1)
        {
            printErrorMessageAndExit("Error creating child process.");
        }
        else if (pid == 0)
        {
            sprintf(command, "./child %s %d %d %d", inputFileName, startPos, segmentLength, currentProcess);
            execl("/bin/sh", "sh", "-c", command, (char *)NULL);
            exit(0);
        }
        else
        {
            int exitCode;
            waitpid(pid, &exitCode, 0);
            totalLowercaseCount += WEXITSTATUS(exitCode);
        }

        startPos += segmentLength;
        currentProcess++;
    }

    printf("Total lowercase count from all processes: %d\n", totalLowercaseCount);

    return 0;
}

